//
//  NetworkAccess.swift
//  PankajWeatherAssignment
//
//  Created by Admin on 16/09/23.
//

import Foundation
struct NetworkAccess {
        static let apiKey = "8a2e0540c0f64cafbf873650231609"
        static let currentbaseURL = "https://api.weatherapi.com/v1/current.json"
        static let nextFourDaysBaseURL = "https://api.weatherapi.com/v1/forecast.json"
}
