//
//  ViewController.swift
//  PankajWeatherAssignment
//
//  Created by Admin on 16/09/23.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    
    @IBOutlet weak var searchTxtField: UITextField!
    @IBOutlet weak var cityLbl: UILabel!
    @IBOutlet weak var stateLbl: UILabel!
    @IBOutlet weak var forcasteImage: UIImageView!
    @IBOutlet weak var rainType: UILabel!
    @IBOutlet weak var dateForcastLbl: UILabel!
    @IBOutlet weak var degreeLbl: UILabel!
    @IBOutlet weak var windLbl: UILabel!
    @IBOutlet weak var humidityLbl: UILabel!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var viewWind: UIView!
    @IBOutlet weak var viewHumidity: UIView!
    
  
    var weatherData = [WeatherData]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
           makeUpUI()
        // Set the delegate of the UITextField to self
        searchTxtField.delegate = self
        // Add a UITapGestureRecognizer to dismiss the keyboard
                let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                view.addGestureRecognizer(tapGesture)

    }
    func makeUpUI(){
        mainView.layer.cornerRadius = 24
        viewWind.layer.borderWidth = 1
        viewWind.layer.borderColor = UIColor.white.cgColor
        viewHumidity.layer.borderWidth = 1
        viewHumidity.layer.borderColor = UIColor.white.cgColor
        viewHumidity.layer.cornerRadius = 24
        viewHumidity.layer.maskedCorners = [.layerMaxXMaxYCorner]
        viewHumidity.layer.masksToBounds = true
        searchTxtField.layer.borderWidth = 2
        searchTxtField.layer.borderColor = UIColor.gray.cgColor
        searchTxtField.layer.cornerRadius = 10
        viewWind.layer.cornerRadius = 24
        viewWind.layer.maskedCorners = [.layerMinXMaxYCorner]
        viewWind.layer.masksToBounds = true
    }
    @objc func dismissKeyboard() {
           // This will dismiss the keyboard for the active text field (if any)
           view.endEditing(true)
       }
// Api call
    
    func getCurrentWeather(for city: String, completion: @escaping (Result<WeatherData, Error>) -> Void) {
        guard let url = URL(string: "\(NetworkAccess.currentbaseURL)?key=\(NetworkAccess.apiKey)&q=\(city)") else {
            completion(.failure(NSError(domain: "Invalid URL", code: 0, userInfo: nil)))
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            if let data = data {
                do {
                    let dataWeather = try JSONDecoder().decode(WeatherData.self, from: data)
                    DispatchQueue.main.async {
                        self.cityLbl.text = "\(dataWeather.location?.name ?? "No matching location found")"
                        self.stateLbl.text = dataWeather.location?.region
                        self.degreeLbl.text = "\(dataWeather.current?.temp_c ?? 0)°C"
                        self.rainType.text = dataWeather.current?.condition?.text
                        self.dateForcastLbl.text = dataWeather.location?.localtime
                        self.windLbl.text = "\(dataWeather.current?.wind_kph ?? 0) KPH"
                        self.humidityLbl.text = "\(dataWeather.current?.humidity ?? 0) g.m-3"
                        self.forcasteImage.image = UIImage(named: String(dataWeather.current?.condition?.code ?? 1000))
                        
                        completion(.success(dataWeather))
                    }
                } catch {
                    completion(.failure(error))
                }
            }
        }.resume()
    }
    
    
    @IBAction func searchBtnAction(_ sender: Any) {
        Spinner.start()
            self.getCurrentWeather(for: self.searchTxtField.text ?? "No matching location found") { result in
                Spinner.stop()
                       switch result {
                       case .success(let weatherData):
                           print(weatherData)
                       case .failure(let error):
                           // Handle error, display an error message to the user
                           print("Error fetching weather: \(error)")
                       }
                   
        }
       
    }
    
    @IBAction func nextDaysBtnAction(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "NextFourDaysVC") as! NextFourDaysVC
        vc.currentCity = cityLbl.text ?? ""
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

